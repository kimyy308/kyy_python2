import scipy.io
mat = scipy.io.loadmat('file.mat')
