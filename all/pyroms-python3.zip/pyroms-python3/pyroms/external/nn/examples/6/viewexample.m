viewinterp('data.txt', 'nn.txt');
