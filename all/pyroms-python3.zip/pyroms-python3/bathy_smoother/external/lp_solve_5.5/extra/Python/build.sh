:
python setup.py install
